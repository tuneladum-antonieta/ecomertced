import { Link } from 'react-router-dom';
import styles from './cabecalho.module.css';

function Header() {
    return (
        <header className={styles.header}>
            <div className={styles.logo}>
                <Link to="/">Loja</Link>
            </div>
            <nav className={styles.nav}>
                <ul className={styles.navList}>
                    <li className={styles.navItem}>
                        <Link to="/produtos">Produtos</Link>
                    </li>
                    <li className={styles.navItem}>
                        <Link to="/sobre">Sobre</Link>
                    </li>
                    <li className={styles.navItem}>
                        <Link to="/contato">Contato</Link>
                    </li>
                </ul>
            </nav>
        </header>
    );
}

export default Header;