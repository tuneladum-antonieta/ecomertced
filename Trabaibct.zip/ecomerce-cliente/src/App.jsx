import AppRoutes from "./rotas"


function App() {
  return (
    <AppRoutes />
  )
}

export default App